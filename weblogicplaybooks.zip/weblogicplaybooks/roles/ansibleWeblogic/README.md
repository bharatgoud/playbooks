Oracle Weblogic Ansible Role
============================

This role installs Oracle Weblogic

Requirements
------------
This role requires the followed files:
- JDK downloaded from Oracle.com and renamed for example from: "jdk-7u55-linux-x64.rpm" to "jdk-linux-x64.rpm"
- Oracle Weblogic jar downloaded from Oracle.com => wls1036_generic.jar

Those files will have to be in "oracle_repository: /opt/repo/oracle"

License
-------
GPLv2

Author Information
------------------

Angelo Cesaro
cesaro.angelo@gmail.com
