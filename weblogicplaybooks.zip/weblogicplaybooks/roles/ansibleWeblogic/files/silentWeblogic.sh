WL_HOME=/opt/oracle/weblogic/wlserver_10.3
DOMAIN_HOME=/opt/oracle/weblogic/user_projects/domains/SitesDomain
PRE_CLASSPATH=/opt/oracle/weblogic/user_projects/domains/CS/WEB-INF/lib/commons-lang-2.4.jar

# 20140704 update classpath env.var
# CLASSPATH=/opt/oracle/weblogic/patch_wls1036/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/opt/oracle/weblogic/patch_ocp371/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/usr/java/latest/lib/tools.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/weblogic.jar:/opt/oracle/weblogic/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/webservices.jar:/opt/oracle/weblogic/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/oracle/weblogic/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar

CLASSPATH=/usr/java/latest/lib/tools.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/weblogic.jar:/opt/oracle/weblogic/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/oracle/weblogic/wlserver_10.3/server/lib/webservices.jar:/opt/oracle/weblogic/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/oracle/weblogic/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar


PATH=/opt/oracle/weblogic/wlserver_10.3/server/bin:/opt/oracle/weblogic/modules/org.apache.ant_1.7.1/bin:/usr/java/latest/jre/bin:/usr/java/latest/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/weblogic/bin:/usr/java/latest/bin:/home/weblogic/bin:/usr/java/latest/jre/bin:/home/weblogic/bin
export WL_HOME
export DOMAIN_HOME
export PRE_CLASSPATH
export CLASSPATH
export PATH
