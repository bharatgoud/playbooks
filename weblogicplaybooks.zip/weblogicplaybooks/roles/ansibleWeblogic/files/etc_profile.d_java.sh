JAVA_VENDOR=Sun
JAVA_HOME=/usr/java/latest
PATH=$PATH:$HOME/bin:$JAVA_HOME/bin
JRE_HOME=/usr/java/latest/jre
PATH=$PATH:$HOME/bin:$JRE_HOME/bin
export JAVA_VENDOR
export JAVA_HOME
export JRE_HOME
export PATH

