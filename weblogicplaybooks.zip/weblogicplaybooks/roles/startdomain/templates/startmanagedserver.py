connect("weblogic", "weblogic", "t3://localhost:7002")
start('myServer_1', 'Server')
exit()
